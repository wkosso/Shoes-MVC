<?php
/**
 * Author: William Kosso
 * Date: 4/2/2023
 * File: shoe_model.class.php
 * Description:
 */

class ShoeModel
{

    //private data members
    private $db;
    private $dbConnection;
    static private $_instance = NULL;
    private $tblShoe;


    public function __construct()
    {
        $this->db = Database::getDatabase();
        $this->dbConnection = $this->db->getConnection();
        $this->tblShoe = $this->db->getShoeTable();

        //Escapes special characters in a string for use in an SQL statement. This stops SQL inject in POST vars.
        foreach ($_POST as $key => $value) {
            $_POST[$key] = $this->dbConnection->real_escape_string($value);
        }

        //Escapes special characters in a string for use in an SQL statement. This stops SQL Injection in GET vars
        foreach ($_GET as $key => $value) {
            $_GET[$key] = $this->dbConnection->real_escape_string($value);
        }
    }


    //static method to ensure there is just one MovieModel instance
    public static function getShoeModel()
    {
        if (self::$_instance == NULL) {
            self::$_instance = new ShoeModel();
        }
        return self::$_instance;
    }


    /*
     * this method retrieves all toys from the database and
     * returns an array of Toy objects if successful or false if failed.
     */
    public function list_shoe()
    {
        //SQL select statement
        $sql = "SELECT * FROM " . $this->db->getShoeTable();


//execute the query
        $query = $this->dbConnection->query($sql);


// if the query failed, return false.
        if (!$query)
            return false;

//if the query succeeded, but no movie was found.
        if ($query->num_rows == 0)
            return 0;

//handle the result
//create an array to store all returned movies
        $shoes = array();

//loop through all rows in the returned recordsets
        while ($obj = $query->fetch_object()) {
            $shoe = new Shoe(stripslashes($obj->name), stripslashes($obj->brand), stripslashes($obj->price), stripslashes($obj->year), stripslashes($obj->image));
            //set the id for the movie
            $shoe->setId($obj->id);

            //add the movie into the array
            $shoes[] = $shoe;
        }
        return $shoes;
    }


    /*
         * the viewShoe method retrieves the details of the shoe specified by its id
         * and returns a shoe object. Return false if failed.
         */


    public function view_shoe($id)
    {
        //the select ssql statement

        //the select SQL statement
        $sql = "SELECT * FROM " . $this->db->getShoeTable() . " WHERE id = " . $id;


        //execute the query
        $query = $this->dbConnection->query($sql);

        if ($query && $query->num_rows > 0) {
            $obj = $query->fetch_object();

            //create a shoe object
            $shoe = new Shoe(stripslashes($obj->name), stripslashes($obj->brand), stripslashes($obj->price), stripslashes($obj->year), stripslashes($obj->image));
            //set the id for the movie
            $shoe->setId($obj->id);


            return $shoe;
        }

        return false;
    }


    public function search_shoe($terms)
    {
        $terms = explode(" ", $terms); //explode multiple terms into an array

        // select statement for AND search
        $sql = "SELECT * FROM " . $this->db->getShoeTable() . " WHERE 1=1";

        foreach ($terms as $term) {
            $sql .= " AND name LIKE '%" . $term . "%'";
        }

        // execute the query
        $query = $this->dbConnection->query($sql);

        // the search failed, return false.
        if (!$query)
            return false;

        // search succeeded, but no shoe was found.
        if ($query->num_rows == 0)
            return 0;

        // create an array to store all returned shoes
        $shoes = array();

        // loop through all rows in the returned recordsets
        while ($obj = $query->fetch_object()) {
            $shoe = new Shoe(stripslashes($obj->name), stripslashes($obj->brand), stripslashes($obj->price), stripslashes($obj->year), stripslashes($obj->image));
            // set the id for the shoe
            $shoe->setId($obj->id);

            // add the shoe into the array
            $shoes[] = $shoe;
        }
        return $shoes;
    }


    public function add_shoe($shoes)
    {

        $name = $this->dbConnection->escape_string($shoes->getName());
        $brand = $this->dbConnection->escape_string($shoes->getBrand());
        $price = $this->dbConnection->escape_string($shoes->getPrice());
        $year = $this->dbConnection->escape_string($shoes->getYear());
        $image = $this->dbConnection->escape_string($shoes->getImage());
        //$image_size=getimagesize($image);
//        if($image_size!==false){
//            echo"image: {$image_size[0]} pixle wide and {$image_size[1]} pixle tall";
//        } else{
//          echo "unable to get information";
//        }


        // SQL insert statement
        $sql = "INSERT INTO " . $this->tblShoe . " (name, brand, price, year, image) VALUES ('$name', '$brand', '$price', '$year', '$image')";

        // Execute the query
        $query = $this->dbConnection->query($sql);

        // Return true if the query succeeded, false otherwise
        return $query ? true : false;

    }


    public function update_shoe($id)
    {
        //if the script did not received post data, display an error message and then terminite the script immediately
        if (!filter_has_var(INPUT_POST, 'name') ||
            !filter_has_var(INPUT_POST, 'brand') ||
            !filter_has_var(INPUT_POST, 'price') ||
            !filter_has_var(INPUT_POST, 'year') ||
            !filter_has_var(INPUT_POST, 'image')
        ) {

            return false;
        }


        $name = $this->dbConnection->real_escape_string(trim(filter_input(INPUT_POST, 'name', FILTER_SANITIZE_FULL_SPECIAL_CHARS)));
        $brand = $this->dbConnection->real_escape_string(trim(filter_input(INPUT_POST, 'brand', FILTER_SANITIZE_FULL_SPECIAL_CHARS)));
        $price = $this->dbConnection->real_escape_string(trim(filter_input(INPUT_POST, 'price', FILTER_SANITIZE_FULL_SPECIAL_CHARS)));
        $year = $this->dbConnection->real_escape_string(trim(filter_input(INPUT_POST, 'year', FILTER_SANITIZE_FULL_SPECIAL_CHARS)));
        $image = $this->dbConnection->real_escape_string(trim(filter_input(INPUT_POST, 'image', FILTER_SANITIZE_FULL_SPECIAL_CHARS)));


//query string for update
        $sql = "UPDATE " . $this->tblShoe .
            " SET name='$name', brand='$brand', price='$price', year='$year', "
            . "image='$image' WHERE id='$id'";

        return $this->dbConnection->query($sql);

    }

}