<?php
/**
 * Author: William Kosso
 * Date: 4/2/2023
 * File: shoe.class.php
 * Description:
 */

class Shoe
{
//private data members
    private $id, $name, $brand, $price, $year, $image;



    public function __construct($name, $brand, $price, $year,$image) {

        $this->name = $name;
        $this->brand = $brand;
        $this->price = $price;
        $this->year = $year;
        $this->image = $image;

    }

    /**
     * @return mixed
     */

    //getters
    public function getId() {
        return $this->id;
    }

    public function getName()
    {
        return $this->name;
    }

    /**
     * @return mixed
     */
    public function getBrand()
    {
        return $this->brand;
    }

    /**
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @return mixed
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * @return mixed
     */
    public function getImage()
    {
        return $this->image;
    }


    //set shoe id
    public function setId($id) {
        $this->id = $id;
    }

}