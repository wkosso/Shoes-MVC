<?php
/**
 * Author: William Kosso
 * Date: 4/18/2023
 * File: users.class.php
 * Description:
 */

class Users
{

    private $id, $firstname, $lastname, $email, $username, $password, $role;

//constructor that initializes guest properties
    public function __construct($firstname, $lastname, $email, $username, $password, $role)
    {

        $this->firstname = $firstname;
        $this->lastname = $lastname;
        $this->email = $email;
        $this->username = $username;
        $this->password = $password;
        $this->role = $role;


    }



    /**
     * @param mixed $id
     */
    public function setId($id): void
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getFirstname()
    {
        return $this->firstname;
    }



    /**
     * @return mixed
     */
    public function getLastname()
    {
        return $this->lastname;
    }



    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }



    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }



    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }



    /**
     * @return mixed
     */
    public function getRole()
    {
        return $this->role;
    }

    // Setter methods
    public function setRole($role) {
        $this->role = $role;
    }


}