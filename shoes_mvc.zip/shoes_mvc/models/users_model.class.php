<?php
/**
 * Author: William Kosso
 * Date: 4/18/2023
 * File: users_model.class.php
 * Description:
 */


class UsersModel
{

    //private data members
    private $db;
    private $dbConnection;
    static private $_instance = NULL;
    private $tblUsers;
    private $tblRoles;


    public function __construct()
    {
        $this->db = Database::getDatabase();
        $this->dbConnection = $this->db->getConnection();
        $this->tblUsers = $this->db->getUsersTable();

        //Escapes special characters in a string for use in an SQL statement. This stops SQL inject in POST vars.
        foreach ($_POST as $key => $value) {
            $_POST[$key] = $this->dbConnection->real_escape_string($value);
        }

        //Escapes special characters in a string for use in an SQL statement. This stops SQL Injection in GET vars
        foreach ($_GET as $key => $value) {
            $_GET[$key] = $this->dbConnection->real_escape_string($value);
        }
    }


    public static function getUsersModel()
    {
        if (self::$_instance == NULL) {
            self::$_instance = new UsersModel();
        }
        return self::$_instance;
    }

    public function getUsers()
    {

        $query = "SELECT * FROM users";
        $result = $this->dbConnection->query($query);
        $users = array();
        while ($row = $result->fetch_assoc()) {
            $user = new Users($row['firstname'], $row['lastname'], $row['email'], $row['username'], $row['password'], $row['role']);
            $user->setId($row['id']);
            $users[] = $user;
        }
        return $users;
    }


    public function addUser($user)
    {

        $firstname = $this->dbConnection->escape_string($user->getFirstName());
        $lastname = $this->dbConnection->escape_string($user->getLastName());
        $email = $this->dbConnection->escape_string($user->getEmail());
        $username = $this->dbConnection->escape_string($user->getUsername());
        $password = $this->dbConnection->escape_string($user->getPassword());
        $role = $this->dbConnection->escape_string($user->getRole());

        // set role if it is empty
        if(empty($role)){
            $role = "user";
            $user->setRole($role);
        }


        $sql = "INSERT INTO " . $this->tblUsers . $this->tblRoles . " (firstname, lastname, email, username, password, role) VALUES ('$firstname', '$lastname', '$email', '$username', '$password', '$role')";


        $query = $this->dbConnection->query($sql);

        // Return true if the query succeeded, false otherwise
        return $sql ? true : false;



    }


//TODO: validate user's credential with username and password
    public function validate($username, $password)
    {
        //1. sql statement SELECT with username and password
        //2. run the sql
        //3, if num_rows == 1, pass the validate
        //4 if num_rows == 0, fail the validate

//
//        //validate user name and password against a record in the users table in the database. If they are valid, create session variables.
//        $sql = "SELECT * FROM users WHERE username='$username' AND role='$role' AND password='$password'";
//
//
//        $query = $this->dbConnection->query($sql);
//
//        // check number of rows returned
//        if ($query->num_rows == 1) {
//            //$row = $query->fetch_assoc();
//            // if user is validated, create session variables
//            $_SESSION['username'] = $username;
//            $_SESSION['password'] = $password;
//          //  $_SESSION['row'] = $row['role'];
//            $_SESSION['role'] = $role;
//
//            return true;
//        } else {
//            if ($query->num_rows == 0) {
//                return false;
//
//
//            }
//        }
//
//    }




//validate user name and password against a record in the users table in the database. If they are valid, create session variables.
        $sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";

        $query = $this->dbConnection->query($sql);
        if ($query->num_rows) {
            $row = $query->fetch_assoc();
            $_SESSION['username'] = $username;
            $_SESSION['password'] = $password;
            $_SESSION['role'] = $row['role'];
            $_SESSION['login_status'] = $row['role'];
            return true;
        } else {
            return false;
        }



    }
}