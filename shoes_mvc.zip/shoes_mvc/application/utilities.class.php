<?php
/**
 * Author: William Kosso
 * Date: 4/23/2023
 * File: utilities.class.php
 * Description:
 */
class Utilities
{
    // Validate an email address. A valid email address appears in the format of "username@domain.domain".
    public static function validateEmail($email)
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    public static function validateUsername($username)
    {
        if (empty($username)) {
            return false; // username is empty, return false
        }


    }



}