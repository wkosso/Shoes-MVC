<?php
/**
 * Author: William Kosso
 * Date: 4/23/2023
 * File: DataFormatException.class.php
 * Description:
 */
class DataFormatException extends Exception
{

    //constructor with three parameters
    public function __construct($message, $code = 0, Exception $previous = null)
    {
        //call the parent constructor
        parent::__construct($message, $code, $previous);
    }

    //toString method
    public function __toString()
    {
        return __CLASS__ . ": [{$this->code}]: {$this->message}\n";
    }
}