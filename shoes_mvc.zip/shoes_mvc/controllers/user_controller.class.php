<?php
/**
 * Author: William Kosso
 * Date: 4/18/2023
 * File: user_controller.class.php
 * Description:
 */

Class UserController
{


    private $user_model;


    public function __construct()
    {
        //create an object of the ToyModel class
        $this->user_model = new UsersModel();
    }


    //list all toys
    public function index()
    {
        //retrieve all toys and store them in an array
        $users = $this->user_model->getUsers();

        //if there is no toy to display, display an error message
        if (!$users) {
            header("Location: index.php?action=error&message=No guest was found.");
            exit();
        }


        //create an object of the guest class
        $view = new UserIndex();
        //display all toys
        $view->display($users);

    }


    public function register()
    {

            // Start the session if it is not active
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }

            // Retrieve the user details from the form submission
            $firstname = isset($_POST['firstname']) ? $_POST['firstname'] : '';
            $lastname = isset($_POST['lastname']) ? $_POST['lastname'] : '';
            $email = isset($_POST['email']) ? $_POST['email'] : '';
            $username = isset($_POST['username']) ? $_POST['username'] : '';
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            $role = 3;

            // Sanitize the input data
            $firstname = filter_var($firstname, FILTER_SANITIZE_SPECIAL_CHARS);
            $lastname = filter_var($lastname, FILTER_SANITIZE_SPECIAL_CHARS);
            $email = filter_var($email, FILTER_SANITIZE_EMAIL);
            $username = filter_var($username, FILTER_SANITIZE_SPECIAL_CHARS);
            $password = filter_var($password, FILTER_SANITIZE_SPECIAL_CHARS);
            //$role = filter_var($role, FILTER_SANITIZE_SPECIAL_CHARS);



        try {

            if (empty($username)) {
                throw new DataFormatException("Username cannot be empty.");
            }



            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new DataFormatException("Email address is not in the correct format.");
            }


//        // Validate the email address
//        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
//            // Display an error message if the email address is not valid
//            $view = new UserError();
//            $view->display('Invalid email address');
//            return;
//        }


            // Create a new User object and add it to the database
            $user = new Users($firstname, $lastname, $email, $username, $password, $role);

// If the role is empty, set it to a default value
            if (empty($role)) {
                $user->setRole('default_role');
            }

            $users_model = new UsersModel();
            $users_model->addUser($user);

            // Create session variables
            $_SESSION['login'] = $username;
            $_SESSION['name'] = "$firstname $lastname";
            $_SESSION['role'] = $role;

            // Set login status to 3 since this is a new user
            $_SESSION['login_status'] = 3;

            $view = new WelcomeIndex();
            $view->display();
        } catch (DataFormatException $e) {
            // Display a confirmation message
            $view = new UserError();
            $view->display($e->getMessage());

        }

    }




    public function add()
    {

// Display adding shoes page
        $view = new  UserAdd();
        $view->display();


    }

    //TODO: authenicate user's name and password
    public function authenticate()
    {
        //1. retrive form data username and password
        //2. pass username and password to the user model to validate.
        //3 if pass the validate, redict user's to a welcome back view or other view
        //4. if not pass the validate, redict user to an warning view


        //start session if it has not already started
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }

//create variable login status.

        $_SESSION['login_status'] = 0;

        // retrieve form data username and password
        $username = $_POST['username'];
        $password = $_POST['password'];


        // pass username and password to the user model to validate
        if ($this->user_model->validate($username, $password)) {
            // credentials are valid, create session variables and redirect to welcome page
            $_SESSION['username'] = $username;
            $_SESSION['password'] = $password;


            $view = new  WelcomeIndex();
            $view->display();
            exit();
        } else {
            // credentials are invalid, show error message or redirect to warning view
            $view = new  UserError();
            $view->display("this is invalid");
            exit();
        }


    }

    //This method displays an error message by calling the display method of an Error object
    public function error($message)
    {
        //create an object of the Error class
        $view = new UserError();

        //display the error page
        $view->display($message);
    }


    public function logout() {
        // Clear user's session
        if(session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION = [];
        session_destroy();

        // Display logout message
        $logout = new logout();
        $logout->display();
    }


}