<?php
/**
 * Author: William Kosso
 * Date: 4/2/2023
 * File: shoe_controller.class.php
 * Description:
 */

class ShoeController
{

    private $shoe_model;

    //default constructor
    public function __construct() {
        //create an instance of the ShoeModel class
        $this->shoe_model = ShoeModel::getShoeModel();
    }

    //index action that displays all movies
    public function index() {

        //retrieve all shoes and store them in an array
        $shoes = $this->shoe_model->list_shoe();
        if (!$shoes) {
            //display an error
            $message = "There was a problem displaying shoes.";
            $this->error($message);
            return;
        }
        // display all shoes
        $view = new ShoeIndex();
        $view->display($shoes);
    }



    //show details of a shoe
    public function detail($id) {

        //retrieve the specific movie
        $shoe = $this->shoe_model->view_shoe($id);
        if (!$shoe) {
            //display an error
            $message = "There was a problem displaying the shoe id='" . $id . "'.";
            $this->error($message);
            return;
        }
        //display shoe details
        $view = new ShoeDetail();
        $view->display($shoe);

    }



    //search movies
    public function search() {
        //retrieve query terms from search form
        $query_terms = trim($_GET['query-terms']);

        //if search term is empty, list all movies
        if ($query_terms == "") {
            $this->index();
        }

        //search the database for matching movies
        $shoes = $this->shoe_model->search_shoe($query_terms);
        var_dump($shoes);

        if ($shoes === false) {
            //handle error
            $message = "An error has occurred.";
            $this->error($message);
            return;
        }
        //display matched movies
        $search = new ShoeSearch();
        $search->display($query_terms, $shoes);
    }

    //autosuggestion
    public function suggest($terms) {
        //retrieve query terms
        $query_terms = urldecode(trim($terms));
        $shoes = $this->shoe_model->search_shoe($query_terms);

        //retrieve all movie titles and store them in an array
        $name = array();
        if ($shoes) {
            foreach ($shoes as $shoe) {
                $name[] = $shoe->getName();
            }
        }

        echo json_encode($name);
    }


    //handle calling inaccessible methods
    public function __call($name, $arguments) {
        //$message = "Route does not exist.";
        // Note: value of $name is case sensitive.
        $message = "Calling method '$name' caused errors. Route does not exist.";

        $this->error($message);
        return;
    }




    public function create()
    {


//retrieve the shoe details from the form submission
        $name = isset($_POST['name']) ? $_POST['name'] : '';
        $brand = isset($_POST['brand']) ? $_POST['brand'] : '';
        $price = isset($_POST['price']) ? $_POST['price'] : '';
        $year = isset($_POST['year']) ? $_POST['year'] : '';
        $image = isset($_POST['image']) ? $_POST['image'] : '';

// Sanitize the input data
        $name = filter_var($name, FILTER_SANITIZE_SPECIAL_CHARS);
        $brand = filter_var($brand, FILTER_SANITIZE_SPECIAL_CHARS);
        $price = filter_var($price, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $year = filter_var($year, FILTER_SANITIZE_NUMBER_INT);
        $image = filter_var($image, FILTER_SANITIZE_SPECIAL_CHARS);;

// Create a new Shoe object and add it to the database
        $shoe = new Shoe($name, $brand,  $price, $year, $image);


        $shoe_model = new ShoeModel();
        $shoe_model->add_shoe($shoe);

        $view = new ShoeController();
        $view->index();
    }



    public function add(){

// Display adding shoes page
        $view = new  ShoeAdd();
        $view->index();




    }



    //display a movie in a form for editing
    public function edit($id) {
        //retrieve the specific movie
        $shoe = $this->shoe_model->view_shoe($id);
        //var_dump($movie);


        if (!$shoe) {
            //display an error
            $message = "There was a problem displaying the shoe id='" . $id . "'.";
            $this->error($message);
            return;
        }

        $view = new ShoeEdit();
        $view->display($shoe);
    }


    //update a movie in the database
    public function update($id) {
        //update the movie
        $update = $this->shoe_model->update_shoe($id);
        if (!$update) {
            //handle errors
            $message = "There was a problem updating the movie id='" . $id . "'.";
            $this->error($message);
            return;
        }

        //display the updateed movie details
        $confirm = "The shoe was successfully updated.";
        $shoe= $this->shoe_model->view_shoe($id);

        $view = new ShoeDetail();
        $view->display($shoe, $confirm);
    }


    //handle an error
    public function error($message) {

        //create an object of the Error class
        $error = new ShoeError();
    //display the error page
        $error->display($message);
    }



}