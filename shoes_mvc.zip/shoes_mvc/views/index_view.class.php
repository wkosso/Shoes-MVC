<?php
/*
 * Author: Louie Zhu
 * Date: Mar 6, 2016
 * Name: index_view.class.php
 * Description: the parent class for all view classes. The two functions display page header and footer.
 */

class IndexView {

    //this method displays the page header
    static public function displayHeader($page_title) {
        if(session_status() == PHP_SESSION_NONE){
            session_start();
        }

        
        ?>

        <!DOCTYPE HTML>
        <html>
        <head>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <link type="text/css" rel="stylesheet" href="www/css/stylesheet.css" />
            <script src="https://kit.fontawesome.com/ba59be7785.js" crossorigin="anonymous"></script>
            <!--<link type="text/css" rel="stylesheet" href=""/> -->
            <title>Affordable Kicks</title>
        </head>


        <body class="bg-light">
        <div id="ribbon"><!-- DIV that handles everything in the top portion of the
                              website.-->
                         <!--
                         This is the current date:
                         -->
        <div class="text-center">
            <div id="dateCurrent" class="p-0 m-0">
                <?php
                date_default_timezone_set('America/New_York');
                echo date("l, F d, Y", time());
                ?>
            </div>
        </div>
        <script>
            //create the JavaScript variable for the base url
            var base_url = "<?= BASE_URL ?>";
        </script>





        <!--Logo Image and Banner -->
        <div class="text-muted m-1"><hr/></div>
        <div id="banner" class="bg-light mt-2 mb-2">
            <div class="row">
                <div class="col-sm-3">
                    <div class="logo" style="margin-top: -5px;">
                        <img class="w-50" src=" <?= BASE_URL ?>/www/img/shoelogo.webp"  style="width: 180px; border: none">
                    </div>
                </div><!-- /.col-sm-4 -->

                <div class="col-sm-6 text-center">
                    <!-- Banner Text: -->
                    <div class="banner-text text-dark">
                        <h2 class="fw-bold pb-3 text-primary">Welcome to Affordable Kicks</h2>


                        <p><small>Welcome to Affordable Kicks shoe catalog, your one-stop destination for quality shoes at affordable prices. We offer a wide range of stylish and comfortable shoes.  </small></p>
                    </div>
                </div><!-- /.col-sm-6 -->
                <div class="col-sm-3">
                    <!-- Shopping cart area: -->

                </div><!-- /.col-sm-3 -->
            </div><!-- /.row -->
        </div><!-- /.banner -->



                      <!-- Nav BAR -->
        <nav class="navbar navbar-expand-lg navbar-light bg-dark justify-content-center">
            <div class="mt-1 mb-1">
                <a href="<?= BASE_URL ?>/shoe/index">
                <a class="p-1 fw-bold text-decoration-none orange-text" href="<?= BASE_URL ?>/welcome">HOME</a>

                <a class="p-1 fw-bold text-decoration-none orange-text" href="<?= BASE_URL ?>/shoe/index ">CATALOG</a>
                    <a class="p-1 fw-bold text-decoration-none orange-text" href="<?= BASE_URL ?>/user/add">REGISTER</a>
                    <?php
                    if(isset($_SESSION['role']) && $_SESSION['role'] == 1){?>
                    <a class="p-1 fw-bold text-decoration-none orange-text" href="<?= BASE_URL ?>/shoe/add">UPLOAD ITEM</a>
                    <?php } ?>
                    <?php
                    if (empty($_SESSION['username'])) {
                        echo '<a class="p-1 fw-bold text-decoration-none orange-text" href="' . BASE_URL . '/user/index">LOGIN</a>';
                    } else {
                        echo '<a class="p-1 fw-bold text-decoration-none orange-text" href="' . BASE_URL . '/user/logout">LOGOUT</a>';
                        echo "<span style='color:white; margin-left:100px'>Welcome to Affordable Kicks, " . $_SESSION['username'] . "!</style>";
                    }
                    ?>


                    <!--<a class="p-1 fw-bold text-decoration-none orange-text" href="newitem.php">UPLOAD ITEM</a>       ||-->
               <!-- <a class="p-1 fw-bold text-decoration-none orange-text" href="searchitems.php">SEARCH</a>         ||-->

                <!-- same log function -->
                <!--
                <a class="p-1 fw-bold text-decoration-none orange-text" href="login.php">LOGIN</a>
                -->
            </div>
        </nav>



                    <?php
                }//end of displayHeader function

                //this method displays the page footer
                public static function displayFooter() {
                    ?>
                    </div>
                    <div id="foot" class="bg-secondary text-light p-3">
                        <div class="text-muted"><hr/></div>
                        &copy <?php echo date("Y") ?> Affordable Kicks Store. All Rights Reserved.
                    </div>

                    <script type="text/javascript" src="<?= BASE_URL ?>/www/js/ajax_autosuggestion.js"></script>
            </body>
        </html>
        <?php
    } //end of displayFooter function
}
