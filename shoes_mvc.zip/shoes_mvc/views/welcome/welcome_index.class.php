<?php
/*
 * Author: Louie Zhu
 * Date: Mar 6, 2016
 * Name: index.class.php
 * Description: This class defines the method "display" that displays the home page.
 */

class WelcomeIndex extends IndexView {

    public function display() {
        //display page header
        parent::displayHeader("Affordable Kicks Media Library Home");
        ?>

        <div class="container">
            <div class="m-1">
            </div>
            <br>
            <div class="row m-1">
                <div class="col-sm border">
                    <div class="p-3 text-start">
                        <h2>WHO WE ARE:</h2>
                        <p>Affordable Kicks, the ultimate destination for sneaker enthusiasts on a budget. Our mission is to provide you with top-quality sneakers at affordable prices, without compromising on style or comfort</p>
                        <div class="mb-1">
                            <h3>Sourcing:</h3>
                            <p>Join sneaker communities and forums to network with other sneaker enthusiasts who may know of sources for Affordable Kicks.
                                Follow Affordable Kicks on social media platforms to stay up to date on new releases and restocks.
                                Consider purchasing directly from Affordable Kicks to support the brand and ensure authenticity.</p>
                        </div><!-- /.mb-1 -->


                        <div class="mb-1">
                            <h3>Washing:</h3>
                            <p>Before the items get to your door they go through a washing cycle. We only use carbon-neutral detergents
                                This guarantees your items are clean fresh and ready to wear when it gets to your door.</p>
                        </div><!-- /.mb-1 -->


                        <p>Our catalog features a wide selection of high-quality sneakers from top brands such as Nike, Adidas, Puma, Reebok, and more. Whether you're looking for running shoes, basketball shoes, casual sneakers, or something in between, we've got you covered. </p>
                    </div><!-- /.p-3 text-start -->
                    <div class="p-3">
                        <button type="button" class="btn btn-primary fw-bold" onclick="window.location.href= '<?= BASE_URL ?>/shoe/index'">VIEW NOW</button>
                    </div>


                </div><!-- /.col-sm -->
                <div class="col-sm">
                    <img class="w-100 h-100 object-fit-cover" src="<?= BASE_URL ?>/www/img/blueshoe.jpg">
                </div><!-- /.col-sm -->
            </div><!-- /.row -->
        </div>

        <style>
            .object-fit-cover {
                object-fit: cover;
            }
        </style>
        <?php
        //display page footer
        parent::displayFooter();
    }

}
