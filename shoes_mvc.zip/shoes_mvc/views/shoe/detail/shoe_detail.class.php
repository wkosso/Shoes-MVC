<?php
/*
 * Author: Lucas Tetault
 * Date: 4/5/2023
 * Name: shoe_detail.class.php
 * Description: This class describes our shoe products in more detail when clicked on.
 */

class ShoeDetail extends ShoeIndexView
{

    public function display($shoe, $confirm = "")
    {
        //display page header
        parent::displayHeader("Display Shoe Details");

        //retrieve shoe details by calling get methods
        $id = $shoe->getId();
        $name = $shoe->getName();
        $brand = $shoe->getBrand();
        $price = $shoe->getPrice();
        $year = $shoe->getYear();
        $image = $shoe->getImage();
        //  $description = $shoe->getDescription();


        if (strpos($image, "http://") === false and strpos($image, "https://") === false) {
            $image = BASE_URL . "/" . SHOE_IMG . $image;
        }
        ?>

        <div id="main-header" class="text-center"><span class="text-primary">Shoes Details</span></div>
        <style>
            #main-header {
                font-size: 24px;
                font-weight: bold;
                color: blue;
            }

        </style>

        <hr>
        <table id="detail">
            <tr>
                <td style="width: 150px;" rowspan="6">
                    <img class="shoe-img" src="<?= $image ?>" alt="<?= $name ?>"/>

                    <style>
                        .shoe-img {
                            width: 250px;
                        }
                    </style>
                </td>
            </tr>


            <tr>
                <td><strong>Name:</strong></td>
                <td><?= $name ?></td>
            </tr>

            <tr>
                <td><strong>Brand:</strong></td>
                <td><?= $brand ?></td>
            </tr>

            <tr>
                <td><strong>Price:</strong></td>
                <td><?= $price ?></td>
            </tr>

            <tr>
                <td><strong>Year:</strong>
                <td><?= $year ?></td>
            </tr>
            <tr>
                <td><strong>Description:</strong></td>
                <td>NULL</td>
            </tr>
            <tr>
                <td>

        <?php
        if(isset($_SESSION['role']) && $_SESSION['role'] == 1){?>
                    <div id="button-group">
                        <input type="button" id="edit-button" value="   Edit   "
                               onclick="window.location.href = '<?= BASE_URL ?>/shoe/edit/<?= $id ?>'">&nbsp;
                    </div>
        <?php } ?>
                </td>
                <td>
                    <!-- descripiton code here -->

                    <div id="confirm-message"><?= $confirm ?></div>
                </td>
            </tr>


        </table>

        <a href="<?= BASE_URL ?>/shoe/index">Go to shoe list</a>

        <?php
        //display page footer
        parent::displayFooter();
    }

//end of display method
}