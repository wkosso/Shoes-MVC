<?php
/**
 * Author: William Kosso
 * Date: 4/2/2023
 * File: shoe_index_view.class.php
 * Description:
 */

class ShoeIndexView extends IndexView
{

    public static function displayHeader($title) {
        parent::displayHeader($title);
        ?>
        <script>
            //the media type
            var media = "shoe";
        </script>
        <!--create the search bar -->

        <div id="searchbar" style="margin-left: 1000px;">
            <form method="get" action="<?= BASE_URL ?>/shoe/search">
                <input type="text" name="query-terms" id="searchtextbox" placeholder="Search shoes by name" autocomplete="off" onkeyup="handleKeyUp(event)">

                <input type="submit" class="btn btn-primary fw-bold" value="Go" />


            </form>
            <div id="suggestionDiv"></div>
        </div>
<style>#suggestionDiv span {
        display: block;
    }</style>

        <?php
    }

    public static function displayFooter() {
        parent::displayFooter();
    }
}
