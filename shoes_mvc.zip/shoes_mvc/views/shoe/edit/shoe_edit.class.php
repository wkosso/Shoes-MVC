<?php
/**
 * Author: William Kosso
 * Date: 4/27/2023
 * File: shoe_edit.class.php
 * Description:
 */

class ShoeEdit extends ShoeIndexView {

public function display($shoe) {
//display page header
parent::displayHeader("Edit shoe");




//retrieve movie details by calling get methods
$id = $shoe->getId();
$name = $shoe->getName();
$brand = $shoe->getBrand();
$price= $shoe->getPrice();
$year = $shoe->getYear();
$image = $shoe->getImage();

?>


  <div id="main-header">Edit Shoe Details</div>

        <!-- display movie details in a form -->
        <form class="new-media"  action='<?= BASE_URL . "/shoe/update/" . $id ?>' method="post" style="border: 1px solid #bbb; margin-top: 10px; padding: 10px;">
            <input type="hidden" name="id" value="<?= $id ?>">

            <p><strong>Name</strong><br>
                <input name="name" type="text" size="100" value="<?= $name ?>" required=""></p>

            <p><strong>Brand</strong><br>
                <input name="brand" type="text" size="100" value="<?= $brand ?>" required=""></p>

            <p><strong>Price</strong><br>
                <input name="price" type="text" size="100" value="<?= $price ?>" required=""></p>

            <p><strong>Year</strong><br>
                <input name="year" type="text" size="100" value="<?= $year ?>" required=""></p>


            <p><strong>Image</strong>: url (http:// or https://) or local file including path and file extension<br>
                <input name="image" type="text" size="100" required value="<?= $image ?>"></p>

            <input type="submit" name="action" value="Update Shoe">
            <input type="button" value="Cancel" onclick='window.location.href = "<?= BASE_URL . "/shoe/detail/" . $id ?>"'>
        </form>
    <?php
    //display page footer
    parent::displayFooter();
}

//end of display method
}



