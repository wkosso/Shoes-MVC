<?php
/**
 * Author: William Kosso
 * Date: 4/11/2023
 * File: shoe_search.class.php
 * Description:
 */


class ShoeSearch extends ShoeIndexView
{
    public function display($terms, $shoes) {
        //display page header
        parent::displayHeader("Search Results");
        ?>
        <div id="main-header"> Search Results for <i><?= $terms ?></i></div>
        <hr>

        <!-- display all records in a grid -->
        <div class="container">
            <div class="row">
                <?php
                if ($shoes === 0) {
                    echo "<div class='col'><p class='text-center'>No shoe was found.</p></div>";
                } else {
                    //display shoes in a grid; six shoes per row
                    foreach ($shoes as $i => $shoe) {
                        $id = $shoe->getId();
                        $name = $shoe->getName();
                        $brand = $shoe->getBrand();
                        $price = $shoe->getPrice();
                        $year = $shoe->getYear();
                        $image = $shoe->getImage();
                        if (strpos($image, "http://") === false and strpos($image, "https://") === false) {
                            $image = BASE_URL . "/" . SHOE_IMG . $image;
                        }
                        ?>
                        <div class='col-md-4 mb-4'>
                            <div class='card h-100'>
                                <a href='<?php echo BASE_URL . "/shoe/detail/$id"; ?>'>
                                    <img class='card-img-top' src='<?php echo $image; ?>' alt=''>
                                </a>
                                <div class='card-body'>
                                    <h5 class='card-title'><?php echo $name; ?></h5>
                                    <p class='card-text'><?php echo $brand; ?></p>
                                    <p class='card-text'>$<?php echo number_format($price, 2); ?></p>
                                    <p class='card-text'><?php echo $year; ?></p>
                                </div>
                            </div>
                        </div>
                        <?php
                        if (($i + 1) % 3 == 0) {
                            echo "</div><div class='row'>";
                        }
                    }
                }
                ?>
            </div>
        </div>

        </div>
        <a href="<?= BASE_URL ?>/shoe/index">Go to shoe list</a>
        <?php
        //display page footer
        parent::displayFooter();
    }
}// end of the display method
