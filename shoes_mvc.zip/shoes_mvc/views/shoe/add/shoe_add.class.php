<?php
/**
 * Author: William Kosso
 * Date: 4/11/2023
 * File: shoe_add.class.php
 * Description:
 */

class ShoeAdd extends ShoeIndexView
{
    /*
     * the display method accepts an array of movie objects and displays
     * them in a grid.
     */

    public function index()
    {
        //display page header
        parent::displayHeader("List All shoes");


      //  $image = $shoe->getImage();

        ?>


        <div class="text-center my-4">
            <h2 class="heading_web font-weight-bold text-primary">Upload Shoe</h2>
        </div>



        <table>

            <style>
                label {
                    color: blue;
                    font-weight: bold;
                }

            </style>
            <tr>
                <td style="width: 150px;" rowspan="9">
                    <form action="<?php echo BASE_URL ?>/shoe/create" method="post" enctype="multipart/form-data">
                </td>
            </tr>
            <tr>
                <td style="padding-right: 25px;"><label for="name">Name:</label></td>
                <td><input type="text" id="name" name="name" required style="margin-top: 5px;"></td>
            </tr>

            <tr>
                <td style="padding-right: 25px;"><label for="brand">Brand:</label></td>
                <td><input type="text" id="brand" name="brand" required style="margin-top: 5px;"></td>
            </tr>

            <tr>
                <td style="padding-right: 25px;"><label for="price">Price:</label></td>
                <td><input type="number" id="price" name="price" required style="margin-top: 5px;"></td>
            </tr>

            <tr>
                <td style="padding-right: 25px;"><label for="year">Year:</label></td>
                <td><input type="number" id="year" name="year" required style="margin-top: 5px;"></td>
            </tr>

            <tr>
                <td style="padding-right: 25px;"><label for="image">Image:</label></td>
                <td><input name="image" id="image" type="url" size="100" required style="margin-top: 5px;"></p></td>
            </tr>
            <tr>
                <td style="padding-right: 40px;">

                    <input type="submit" class="btn btn-primary fw-bold" value="Submit">
                </td>
            </tr>


        </table>
        </form>


        <?php

        //display page footer
        parent::displayFooter();
    } //end of display method
}
