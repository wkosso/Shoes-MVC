<?php
/**
 * Author: William Kosso
 * Date: 4/2/2023
 * File: shoe_index.class.php
 * Description:
 */

class ShoeIndex extends ShoeIndexView {
    /*
     * the display method accepts an array of movie objects and displays
     * them in a grid.
     */

    public function display($shoes) {
        //display page header
        parent::displayHeader("List All shoes");

        ?>
        <div id="main-header" class="text-center"><span class="text-primary">Shoes in the Library</span></div>
<style>
    #main-header {
        font-size: 24px;
        font-weight: bold;
        color: blue;
    }

</style>

        <div class="container">
            <div class="row">
                <?php
                if ($shoes === 0) {
                    echo "<div class='col'><p class='text-center'>No shoe was found.</p></div>";
                } else {
                    //display shoes in a grid; four shoes per row
                    foreach ($shoes as $i => $shoe) {
                        $id = $shoe->getId();
                        $name = $shoe->getName();
                        $brand = $shoe->getBrand();
                        $price = $shoe->getPrice();
                        $year = $shoe->getYear();
                        $image = $shoe->getImage();
                        if (strpos($image, "http://") === false AND strpos($image, "https://") === false) {
                            $image = BASE_URL . "/" . SHOE_IMG . $image;
                        }
                        if ($i % 4 == 0) {
                            echo "</div><div class='row'>";
                        }
                        ?>
                        <div class='col-md-3'>
                            <div class='card mb-3'>
                                <a href='<?php echo BASE_URL . "/shoe/detail/$id"; ?>'>
                                    <img class='card-img-top' src='<?php echo $image; ?>' alt=''>
                                </a>
                                <div class='card-body'>
                                    <h5 class='card-title'><?php echo $name; ?></h5>
                                    <p class='card-text'><?php echo $brand; ?></p>
                                    <p class='card-text'>$<?php echo number_format($price, 2); ?></p>
                                    <p class='card-text'><?php echo $year; ?></p>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
        </div>




       <style>
           .card-img-top {
               height: 100%;
               width: 100%;
               object-fit: cover;
           }


       </style>





        <?php
        //display page footer
        parent::displayFooter();

    } //end of display method
}