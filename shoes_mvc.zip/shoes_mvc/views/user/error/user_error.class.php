<?php
/**
 * Author: William Kosso
 * Date: 4/18/2023
 * File: user_error.class.php
 * Description:
 */
Class UserError{

    public function display($message) {
        ?>

        <!DOCTYPE HTML>
        <html>
        <head>
            <title>User  Error</title>
            <link type="text/css" rel="stylesheet" href="includes/style.css" />
        </head>
        <body>
        <table width='500'>
            <tr>
                <td valign='center' align='center'>
                    <img  src=" <?= BASE_URL ?>/www/img/error.jpeg"  style="width: 80px; border: none">
                </td>
                <td valign='top' align='left'>
                    <h3> We're sorry, but an error has occurred.</h3>
                    <?php echo $message; ?>
                    <p><a href="<?= BASE_URL ?>/welcome">HOME</a></p>
                </td>
            </tr>
        </table>
        </body>
        </html>

        <?php
    } //end of display method
} //end of Error class
?>
