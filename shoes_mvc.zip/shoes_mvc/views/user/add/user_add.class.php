<?php
/**
 * Author: William Kosso
 * Date: 4/18/2023
 * File: user_add.class.php
 * Description:
 */
class UserAdd extends IndexView
{
    public function display(){
        parent::displayHeader("sign up page");

        ?>

        <!DOCTYPE HTML>
        <html>
        <head>
            <title>Affordable Kicks Homepage</title>
            <link type="text/css" rel="stylesheet" href="includes/style.css" />
        </head>

        <body>
        <h2>Add User page</h2>

        <form action="<?= BASE_URL ?>/user/register" method="post">
            <label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname" required>

            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname" required>

            <label for="email">Email:</label>
            <input name="email" size="30" />


            <label for="username">Username:</label>
            <input type="text" name="username" size="30" />

            <label for="password">Password:</label>
            <input type="text" id="password" name="password" required>



            <input type="submit" value="Submit">
        </form>


        </body>
        </html>

        <?php
        //display page footer
        parent::displayFooter();

    } //end of display method

}