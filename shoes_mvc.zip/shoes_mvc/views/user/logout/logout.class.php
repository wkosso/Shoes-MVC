<?php
/**
 * Author: William Kosso
 * Date: 4/25/2023
 * File: userlogout.class.php
 * Description:
 */
class logout {
    public function display() {
        if(session_status() == PHP_SESSION_NONE) {
            session_start();
        }

        //unset all the session variables
        $_SESSION = [];

        //delete the session cookie
        setcookie(session_name(), '', time()-60);

        //destory the session
        session_destroy();

        ?>

        <h2>Logout</h2>
        <p>Thank you for your visit. You are now logged out.</p>
        <p><a href="<?= BASE_URL ?>/welcome">HOME</a></p>

        <?php
    }



}
