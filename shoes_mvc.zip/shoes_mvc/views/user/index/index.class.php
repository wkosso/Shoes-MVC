<?php
/**
 * Author: William Kosso
 * Date: 4/18/2023
 * File: index.class.php
 * Description:
 */
class UserIndex extends IndexView
{

    public function display(){
        parent::displayHeader("log in page");

        ?>

        <!DOCTYPE HTML>
        <html>
        <head>
            <title>Affordable Kicks Homepage</title>
            <link type="text/css" rel="stylesheet" href="includes/style.css" />
        </head>

        <body>
        <h2>Form filling page</h2>




        <?php


        $login_status = "";
        if(isset($_SESSION['login_status'])) {
            $login_status = $_SESSION['login_status'];
        }



        if($login_status ==1){

            echo"<p>You are logged in as ", $_SESSION['username'], "</p>";



        }else if ($login_status == 3) {
            echo "<p>Thank you for registering with us.Your account has been created.</p>";


            exit;
        }
        ?>

        <form action="<?= BASE_URL ?>/user/authenticate" method="post">
            <!--<label for="firstname">First Name:</label>
            <input type="text" id="firstname" name="firstname" required>

            <label for="lastname">Last Name:</label>
            <input type="text" id="lastname" name="lastname" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
-->
            <label for="username">User name:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="text" id="password" name="password" required>



            <input type="submit" value="Submit">
        </form>


        <p><a href="<?= BASE_URL ?>/user/logout">Logout</a></p>
        </body>
        </html>

        <?php
        //display page footer
        parent::displayFooter();

    } //end of display method
}